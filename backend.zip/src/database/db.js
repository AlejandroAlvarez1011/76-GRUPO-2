module.exports = {
    db: "mongodb+srv://misiontic:mision2020@cluster0.vd4cv.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
    
}